# mz — HBuilderX 5+ App 工程

把 maxAOZX 前端应用 build 后的静态文件打包成 HBuilderX 5+ App（HTML5+）项目，可直接云打包 Android / iOS。

## 目录结构

```
mz-hbuilderx/
├── manifest.json       # 5+ App 配置
├── index.html          # App 入口
├── logo.png           # 应用图标（透明底）
└── assets/
    ├── index-*.js     # React bundle（HashRouter，WebView 兼容）
    └── index-*.css
```

## 导入 HBuilderX

1. 打开 HBuilderX
2. 文件 → 导入 → 从本地目录导入
3. 选择本目录 `mz-hbuilderx`
4. HBuilderX 识别为 5+ App 项目

## 首次配置（必须）

1. 双击打开 `manifest.json`，进入可视化界面
2. 点「重新获取」按钮，获取真实 AppID
3. 确认右上角已登录 DCloud 账号

## 云打包

- **Android**：发行 → App-Android/iOS-云打包 → 选 Android，免费即可出 APK
- **iOS**：需要 DCloud 会员 + Apple 开发者证书（p12 + mobileprovision）

## 前端源码更新

前端源码在 `../crypto-analytics/`。改完后：

```bash
cd crypto-analytics
npm run build
# 把 dist/output/index.html 和 dist/output_resource/assets/* 拷贝回本目录
```
